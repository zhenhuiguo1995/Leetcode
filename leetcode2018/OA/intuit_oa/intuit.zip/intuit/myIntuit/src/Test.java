import java.util.*;

public class Test {


    public boolean canSchedule(List<Interval> intervals, int starttime, int endtime) {
        if (intervals == null) return false;

        intervals.sort((Comparator.comparingInt(o -> o.start)));


        for (int i = 0; i < intervals.size(); i++) {
            if (starttime < intervals.get(i).end && endtime > intervals.get(i).start)
                return false;//有交叉
        }

        return true;
    }


    //merge intervals
    public List<String> merge1(List<Interval> intervals) {
        if (intervals.size() <= 1) {
            return new ArrayList<>();
        }
        intervals.sort(Comparator.comparingInt(i -> i.start));

        List<Interval> mergedList = new LinkedList<>();
        for (Interval interval : intervals) {
            if (mergedList.isEmpty() || ((LinkedList<Interval>) mergedList).getLast().end < interval.start)
                mergedList.add(interval);
            else
                ((LinkedList<Interval>) mergedList).getLast().end = Math.max(((LinkedList<Interval>) mergedList).getLast().end, interval.end);
        }

        List<String> res = new LinkedList<>();

        res.add(0 + "-" + mergedList.get(0).start);
        System.out.println(0 + "-" + mergedList.get(0).start);

        for (int i = 0; i < mergedList.size() - 1; i++) {
            System.out.println(mergedList.get(i).end + "-" + mergedList.get(i + 1).start);
            res.add(mergedList.get(i).end + "-" + mergedList.get(i + 1).start);
        }

        return res;
    }


    //longest common history
    public List<String> longestCommonHistory(String[] a, String[] b) {

        //dp[i][j] be the length of the longest common substring ending at a[i] and b[j].(其中最长的)

        int m = a.length, n = b.length;
        int[][] dp = new int[m][n];

        int max = 0, end = 0;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                if (i == 0 || j == 0) {
                    dp[i][j] = 0;
                    continue;
                }


                if (a[i] == b[j]) {
                    dp[i][j] = dp[i - 1][j - 1] + 1;
                } else {
                    dp[i][j] = 0;
                }
                if (max < dp[i][j]) {
                    max = dp[i][j];
                    end = i;
                }
            }
        }

        List<String> res = new LinkedList<>();
        while (max > 0) {
            ((LinkedList<String>) res).addFirst(a[end--]);
            max--;
        }
        for (String s : res)
            System.out.println(s);
        return res;
    }


    /*domain click time

    给广告在每个domain上被click的次数
             要求返回domain及其所有sub domain 被click的总次数
    输入：[
               ["google.com", "60"],
               ["yahoo.com", "50"],
               ["sports.yahoo.com", "80"]
             ]
    输出：    [
                ["com", "190"], (60+50+80)
                ["google.com", "60"],
                ["yahoo.com", "130"] (50+80)
                ["sports.yahoo.com", "80"]
             ]

    */
    public Map<String, Integer> domain (String[][] input) {
        Map<String, Integer> map = new HashMap<>();
        for (String[] str: input) {
            int count = Integer.valueOf(str[1]);
            String domain = str[0];
            String[] parts = domain.split("\\.");
            String curr = "";
            for (int i = parts.length - 1; i >= 0 ; i--) {
                if (i == parts.length - 1) {
                    curr = parts[i];
                } else {
                    curr = parts[i] + "." + curr;
                }
                map.put(curr, map.getOrDefault(curr, 0) + count);
            }
        }
        for (String s : map.keySet())
            System.out.println(s);
        return map;
    }
    /*

    第一題是給你一個string例如"2+3-999" 回傳計算結果int
    第二題加上parenthesis 例如"2+((8+2)+(3-999))"一樣回傳計算結果
    第三道题是加了变量名的。。会给你一个map比如{'a':1, 'b':2, 'c':3}，假设输入为"a+b+c+1"输出要是7，如果有未定义的变量，比如"a+b+c+1+d"输出就是7+d
     */
    //cal1
    public int cal1(String s) {
        int len = s.length(), res = 0, sign = 1;
        for (int i = 0; i < len; i++) {
            char c = s.charAt(i);
            if (Character.isDigit(c)) {
                int temp = c - '0';
                while (i + 1 < len && Character.isDigit(s.charAt(i + 1))) {
                    temp = temp * 10 + s.charAt(i + 1) - '0';
                    i++;
                }
                res += temp * sign;
            } else if (c == '+') {
                sign = 1;
            } else if (c == '-') {
                sign = -1;
            }
        }
        System.out.println(res);
        return res;
    }

    //cal2
    public int cal2(String s) {
        int len = s.length(), res = 0, sign = 1;
        Stack<Integer> stack = new Stack<>();

        for (int i = 0; i < len; i++) {
            char c = s.charAt(i);
            if (Character.isDigit(c)) {
                int temp = c - '0';
                while (i + 1 < len && Character.isDigit(s.charAt(i + 1))) {
                    temp = temp * 10 + s.charAt(i + 1) - '0';
                    i++;
                }
                res += temp * sign;
            } else if (c == '+') {
                sign = 1;
            } else if (c == '-') {
                sign = - 1;
            } else if (c == '(') {
                stack.push(res);
                stack.push(sign);
                res = 0;
                sign = 1;
            } else if (c == ')') {
                res = stack.pop() * res + stack.pop();
                //() 内的 + （）之前的
            }
        }
        System.out.println(res);
        return res;
    }

    //cal3
    public int cal3(String s) {
        int len = s.length(), sum = 0;
        char sign = '+';
        Stack<Integer> stack = new Stack<>();

        for (int i = 0; i < len; i++) {
            char c = s.charAt(i);
            if (Character.isDigit(c)) {
                sum = c - '0';
                while (i + 1 < len && Character.isDigit(s.charAt(i + 1))) {
                    sum = sum * 10 + s.charAt(i + 1) - '0';
                    i++;
                }
            }

            if ((!Character.isDigit(c) && c != ' ') || i == s.length() - 1) {
                if (sign == '+') {
                    stack.push(sum);
                } else if (sign == '-') {
                    stack.push(sum * -1);
                } else if (sign == '*') {
                    stack.push(stack.pop() * sum);
                } else if (sign == '/') {
                    stack.push(stack.pop() / sum);
                }
                sum = 0;
                sign = c;
            }
        }

        int res = 0;
        for (int i : stack) {
            res += i;
        }
        System.out.println(res);
        return res;
    }

    public List<Integer> singleParent(int[][] input) {
        Map<Integer, List<Integer>> map = new HashMap<>();//form a adjacent list
        Map<Integer, Integer> indegree = new HashMap<>();//indegree map
        for (int[] arr : input) {
            if (map.containsKey(arr[0])) {
                map.get(arr[0]).add(arr[1]);
            } else {
                map.put(arr[0], new ArrayList<>());
            }
            indegree.put(arr[1], indegree.getOrDefault(arr[1], 0) + 1);
        }
        List<Integer> res = new ArrayList<>();
        for (int key : indegree.keySet()) {
            if (indegree.get(key) == 1) {
                res.add(key);
            }
        }
        for (int key : map.keySet()) {
            if (!indegree.containsKey(key)) {
                res.add(key);
            }
        }
        return res;
    }

    // q2: 两个指定的点有没有公共祖

    public List<Integer> commonAncestor(int[][] input, int a, int b) {
        Map<Integer, List<Integer>> map = new HashMap<>();//form a adjacent list, child - parents
        for (int[] arr : input) {
            if (map.containsKey(arr[1])) {
                map.get(arr[1]).add(arr[0]);
            } else {
                map.put(arr[1], new ArrayList<>());
            }
        }

        List<Integer> res = new ArrayList<>();
        Set<Integer> ancestorsOfA = new HashSet<>();

        search(map,ancestorsOfA,a);
        compare(map,ancestorsOfA,b,res);

        return res;
        

    }

    public void search(Map<Integer,List<Integer>> map, Set<Integer> ancestorsOfA, int target) {
        //do a dfs on map, add parents to ancestorsOfA
        if (!map.containsKey(target))  return;

        List<Integer> adjParents = map.get(target);

        for (int i = 0; i < adjParents.size(); i++) {
            int parent = adjParents.get(i);
            ancestorsOfA.add(parent);
            search(map, ancestorsOfA, parent);
        }
    }

    public void compare(Map<Integer,List<Integer>> map, Set<Integer> ancestorsOfA, int target, List<Integer> res) {
        //do a dfs on map, add parents to ancestorsOfA
         if (!map.containsKey(target)) return;

         List<Integer> adjParents = map.get(target);
         for (int i = 0; i < adjParents.size(); i++) {
             int parent = adjParents.get(i);
             if (ancestorsOfA.contains(parent)) {
                 res.add(parent);
             } else {
                 compare(map, ancestorsOfA, parent, res);
             }
         }
    }

    public int farestAncestor(int[][] input, int target) {
        Map<Integer, List<Integer>> map = new HashMap<> ();
        for (int[] arr : input) {
            if (map.containsKey(arr[1])) {
                map.get(arr[1]).add(arr[0]);
            } else {
                map.put(arr[1], new ArrayList<>());
            }
        }
        if (!map.containsKey(target)) return -1;
        int res = -1;
        Queue<Integer> q = new LinkedList<> ();

        q.add(target);

        while (!q.isEmpty()) {
            int size = q.size();

            for (int i = 0; i < size; i++) {
                int node = q.poll();
                res = node;
                if (!map.containsKey(node)) continue;

                for (int adj : map.get(node)) {
                     q.add(adj);
                }
            }
        }
        return res;
    }



    public static void main(String[] args) {

        Test t = new Test();

        List<Interval> intervals = new ArrayList<>();
        Interval i1 = new Interval(1, 3);
        Interval i2 = new Interval(4, 7);
        Interval i3 = new Interval(6, 9);
        intervals.add(i1);
        intervals.add(i2);
        intervals.add(i3);
        t.merge1(intervals);


        String[] a = new String[5];
        a[0] = "a";
        a[1] = "b";
        a[2] = "c";
        a[3] = "d";
        a[4] = "g";
        String[] b = new String[4];
        b[0] = "k";
        b[1] = "b";
        b[2] = "c";
        b[3] = "d";
        t.longestCommonHistory(a, b);

        String[] s1 = new String[2];
        s1[0] = "google.com"; s1[1] = "60";
        String[] s2 = new String[2];
        s2[0] = "yahoo.com"; s2[1] = "50";
        String[] s3 = new String[2];
        s3[0] = "sports.yahoo.com"; s3[1] = "80";
        String[][] arr = new String[3][2];
        arr[0] = s1; arr[1] = s2; arr[2] = s3;
        t.domain(arr);


        String s = "3+5-6";
        String ss = "3-(5+6)";
        String sss = "3-5*6-20/4";
        t.cal1(s);
        t.cal2(ss);
        t.cal3(sss);

    }
}
