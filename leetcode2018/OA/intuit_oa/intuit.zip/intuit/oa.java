package intuit;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.TreeMap;

public class oa {
  //common ancestor
  //input: int[][]
  //output: input[0]是input[1] 的parent
  // q1: 只有0个parents和只有1个parent的节点.
  public List<Integer> signleParent(int[][] arrs) {
    Map<Integer, List<Integer>> map = new HashMap<>();
    buildGraph(arrs, map);
    Set<Integer> nodes = new HashSet<>();
    for (int[] arr : arrs) {
      nodes.add(arr[0]);
      nodes.add(arr[1]);
    }
    List<Integer> res = new ArrayList<>();
    for (Integer n : nodes) {
      if (!map.containsKey(n) || map.get(n).size() == 1) {
        res.add(n);
      }
    }
    return res;
  }

  public void buildGraph(int[][] arrs, Map<Integer, List<Integer>> map) {
    for (int[] arr : arrs) {
      int p = arr[0];
      int c = arr[1];
      if (!map.containsKey(p)) {
        map.put(p, new ArrayList<>());
      }
      map.get(p).add(c);
    }
  }

  // q2: 两个指定的点有没有公共祖
  public List<Integer> commonAncestor(int[][] arrs, int a, int b) {
    Map<Integer, List<Integer>> map = new HashMap<>();
    buildGraph(arrs, map);
    List<Integer> res = new ArrayList<>();
    Set<Integer> ancestor = new HashSet<>();
    search(map, a, ancestor, false, res);
    search(map, b, ancestor, true, res);
    return res;
  }

  public List<Integer> search(Map<Integer, List<Integer>> map, int target, Set<Integer> ancestor, boolean check, List<Integer> res) {
    if (!map.containsKey(target)) return null;
    List<Integer> list = map.get(target);
    for (int i = 0; i < list.size(); i++) {
      int parent = list.get(i);
      if (!check) {
        ancestor.add(parent);
        search(map, parent, ancestor, check, res);
      } else {
        if (ancestor.contains(parent)) {
          res.add(parent);
        } else {
          search(map, parent, ancestor, check, res);
        }
      }
    }
    return res;
  }

  //q3: farest ancestor
  public int farestAncestor(int[][] arrs, int target) {
    Map<Integer, List<Integer>> map = new HashMap<>();
    buildGraph(arrs, map);
    if (!map.containsKey(target)) return -1;
    Queue<Integer> queue = new LinkedList<>();
    queue.offer(target);
    int res = -1;
    while (!queue.isEmpty()) {
      int size = queue.size();
      for (int i = 0; i < size; i++) {
        int curNode = queue.poll();
        res = curNode;
        if (!map.containsKey(curNode)) continue;
        List<Integer> parents = map.get(curNode);
        for (int j = 0; j < parents.size(); j++) {
          queue.offer(parents.get(j));
        }
      }
    }
    return res;
  }

  // friends list
  public List<String> output(int[][] arr) {
    Map<Integer, List<Integer>> map = new HashMap<>();
    buildUndirectedGraph(map, arr);
    List<String> res = new ArrayList<>();
    for (Map.Entry<Integer, List<Integer>> entry : map.entrySet()) {
      int cur = entry.getKey();
      List<Integer> neigh = entry.getValue();
      StringBuilder curRes = new StringBuilder();
      curRes.append(cur + " : ");
      for (int i = 0; i < neigh.size(); i++) {
        curRes.append(neigh.get(i) + " ");
      }
      res.add(curRes.toString());
    }
    return res;
  }

  public void buildUndirectedGraph(Map<Integer, List<Integer>> map, int[][] arrs) {
    for (int[] arr : arrs) {
      int a = arr[0];
      int b = arr[1];
      if (!map.containsKey(a)) map.put(a, new ArrayList<>());
      if (!map.containsKey(b)) map.put(b, new ArrayList<>());
      map.get(a).add(b);
      map.get(b).add(a);
    }
  }

  // pretask
  public List<String> preTask(String[][] strs) {
    List<String> res = new ArrayList<>();
    Map<String, Integer> indegree = new HashMap<>();
    buildTopo(strs, indegree);

    return res;
  }

  public void buildTopo(String[][] strs, Map<String, Integer> indegree) {
    for (String[] str : strs) {
      String a = str[0];
      String b = str[1];
      indegree.put(a, 0);
      indegree.put(b, 0);
    }
    for (String[] str : strs) {
      String b = str[1];
      indegree.put(b, indegree.get(b) + 1);
    }
  }

  // security system nlogn
  public void findUnMatch(String[][] strs) {
    Map<String, List<Integer>> map = new TreeMap<>();
    for (String[] str : strs) {
      String employee = str[0];
      String time = str[1];
      if (!map.containsKey(employee)) map.put(employee, new ArrayList<>());
      int t = time.length() == 3 ? Integer.valueOf(time.substring(0, 1)) * 60 + Integer.valueOf(time.substring(1)) :
              Integer.valueOf(time.substring(0, 2)) * 60 + Integer.valueOf(time.substring(2));
      map.get(employee).add(t);
    }
    Map<String, List<Integer>> res = new HashMap<>();
    for (String employee : map.keySet()) {
      List<Integer> time = map.get(employee);
      Collections.sort(time);
      time = map.get(employee);
      check(res, map, employee, time);
    }
    for (String employee : res.keySet()) {
      System.out.println(employee + " : ");
      List<Integer> time = map.get(employee);
      for (int n : time) System.out.print(n + " ");
    }
  }

  public void check(Map<String, List<Integer>> res, Map<String, List<Integer>> map, String employee, List<Integer> time) {
    if (time.size() <= 2) return;
    res.put(employee, new ArrayList<>());
    List<Integer> candidates = new ArrayList<>();
    int start = time.get(0);
    int end = start + 60;
    int count = 1;
    for (int i = 1; i < time.size(); i++) {
      int cur = time.get(i);
      if (cur <= end) {
        count++;
        candidates.add(cur);
      } else {
        if (count >= 3) {
          res.put(employee, new ArrayList<>(candidates));
          return;
        } else {
          count = 1;
          start = time.get(i);
          end = start + 60;
          candidates = new ArrayList<>();
        }
      }
    }
  }

  // find rec
  public List<List<Integer>> find(int[][] arrs) {
    List<List<Integer>> res = new ArrayList<>();
    for (int i = 0; i < arrs.length; i++) {
      for (int j = 0; j < arrs[0].length; j++) {
        if (arrs[i][j] == 0) {
          List<Integer> cur = new ArrayList<>();
          cur.add(i);
          cur.add(j);
          int[] rc = searchRC(arrs, i, j);
          cur.add(rc[0]);
          cur.add(rc[1]);
          flip(arrs, i, j, rc[0], rc[1]);
        }
      }
    }
    return res;
  }

  public int[] searchRC(int[][] arrs, int i, int j) {
    int[] res = new int[2];
    while (j < arrs[0].length && arrs[i][j] == 0) {
      j++;
    }
    while (i < arrs.length && arrs[i][j] == 0) {
      i++;
    }
    res[0] = --i;
    res[1] = --j;
    return res;
  }

  public void flip(int[][] arrs, int lcr, int lcc, int rcr, int rcc) {
    //for(int i = )
  }

  // domain
  public Map<String, Integer> domain(String[][] input) {
    Map<String, Integer> map = new HashMap<>();
    for (String[] str : input) {
      int time = Integer.valueOf(str[1]);
      String domain = str[0];
      String[] parts = domain.split("\\.");
      String cur = new String();
      for (int i = parts.length - 1; i >= 0; i--) {
        if (i == parts.length - 1) cur = parts[i] + cur; // com
        else cur = parts[i] + "." + cur;
        if (!map.containsKey(cur)) map.put(cur, 0);
        map.put(cur, map.get(cur) + time);
      }
    }
    return map;
  }

  // longest common history
  public int lcs(String[] a, String[] b) {
    int res = 0;
    int[][] dp = new int[2][b.length + 1];
    for (int i = 1; i < dp.length; i++) {
      for (int j = 1; j < dp[0].length; j++) {
        if (a[i - 1] == b[j - 1]) {
          dp[i][j] = dp[i - 1][j - 1] + 1;
        } else {
          dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
        }
      }
    }
    return dp[a.length % 2][b.length];
  }

//  public String solution(A[], B[], dp[]){
//    res = [];
//    int i = n;
//    int j = m;
//    while(i > 0 && j > 0){
//      if(A[i] == B[j]){
//        res += A[i];
//        i--;
//        j--;
//      }else if(dp[i - 1, j] < dp[i, j - 1]{
//        // if we don't have the last element in A,
//        //dp[i - 1, j] will have a shorter result
//        j--;
//      }else{
//        i--;
//      }
//    }
//    return res[];
//  }

//  public boolean meetingRoom() {
//
//  }

  /**
   * Definition for an interval.
   * public class Interval {
   *     int start;
   *     int end;
   *     Interval() { start = 0; end = 0; }
   *     Interval(int s, int e) { start = s; end = e; }
   * }
   */

//  class Solution {
//    public String merge(List<Interval> intervals) {
//      Collections.sort(intervals, new Comparator<Interval>(){
//        public int compare(Interval a, Interval b){
//          return a.start - b.start;
//        }
//      });
//      for(int i = 0; i < intervals.size(); i++){
//        if(i < intervals.size() - 1 && intervals.get(i).end >= intervals.get(i + 1).end){
//          intervals.remove(i + 1);
//          i--;
//        }else if(i < intervals.size() - 1 && intervals.get(i).end >= intervals.get(i + 1).start){
//          intervals.get(i).end = intervals.get(i + 1).end;
//          intervals.remove(i + 1);
//          i--;
//        }
//      }
//      String res = new String();
//      for(int i = 0; i < intervals.size(); i++){
//        if(i == 0) res = "0" + " -> " + (intervals.get(0).start - 1);
//        else if(i < intervals.size()){
//          res = res + intervals.get(i - 1).end + " -> " + (intervals.get(i).start - 1);
//        }
//      }
//      return res;
//    }
//  }

  public List<String> longestCommonHistort(String[] a, String[] b){
    List<String> res = new ArrayList<>();
    int n = a.length;
    int m = b.length;
    int[][] dp = new int[n + 1][m + 1];
    int result = Integer.MIN_VALUE;
    int aEnd = 0;
    for(int i = 1; i < dp.length; i++){
      for(int j = 1; j < dp[0].length; j++){
        if(a[i - 1].equals(b[j - 1])){
          dp[i][j] = dp[i - 1][j - 1] + 1;
          if(dp[i][j] > result){
            result = dp[i][j];
            aEnd = i - 1;
          }
        }else{
          dp[i][j] = 0;
        }
      }
    }
    int i = aEnd;
    while(result > 0){
      res.add(a[i--]);
      result--;
    }
    return res;
  }



//class Solution {
//  public int calculate(String s) {
//    if(s.length() == 0) return 0;
//    char sign = '+';
//    int i = 0;
//    Stack<Integer> stack = new Stack<>();
//    if(s.charAt(i) == '-') {
//      sign = '-';
//      i++;
//    }
//    for(; i < s.length(); i++){
//      char c = s.charAt(i);
//      if(c == ' ') continue;
//      else if(Character.isDigit(c)){
//        int cur = c - '0';
//        while(i < s.length() - 1 && Character.isDigit(s.charAt(i + 1))){
//          cur = cur * 10 + s.charAt(i + 1) - '0';
//          i++;
//        }
//        if(sign == '*'){
//          int pre = stack.pop();
//          cur = cur * pre;
//          stack.push(cur);
//        }else if(sign == '/'){
//          int pre = stack.pop();
//          cur = pre / cur;
//          stack.push(cur);
//        }else if(sign == '+'){
//          stack.push(cur);
//        }else{
//          stack.push(-1 * cur);
//        }
//      }else{
//        sign = c;
//      }
//    }
//    int res = 0;
//    while(!stack.isEmpty()){
//      res += stack.pop();
//    }
//    return res;
//  }

  public int uniqueTriangle(int[][] arr){
    if(arr.length == 0) return 0;
    Set<String> set = new HashSet<>();
    for(int[] tri : arr){
      Arrays.sort(tri);
      StringBuilder sb = new StringBuilder();
      for(int n : tri){
        sb.append(n + "");
      }
      String curTri = sb.toString();
      set.add(curTri);
    }
    return set.size();
  }

  // 一个先递增后递减的array问如何logn找一个数
  public int increaseDecrease(int[] arr){
    if(arr.length == 0) return 0;
    int lo = 0;
    int hi = arr.length - 1;
    while(lo <= hi){
      int mid = (hi - lo) / 2 + lo;
      if(mid == 0 || mid == arr.length - 1) return mid;
      if(arr[mid] > arr[mid - 1] && arr[mid] > arr[mid + 1]) return mid;
      if(arr[mid] > arr[mid - 1]){
        lo = mid + 1;
      }else{
        hi = mid - 1;
      }
    }
    return lo;
  }

  public int kthSmallest(int[] input, int k){
    PriorityQueue<Integer> pq = new PriorityQueue<>((a, b) -> b - a);
    for(int n : input){
      if(pq.size() < k){
        pq.offer(n);
      }else{
        if(n < pq.peek()){
          pq.poll();
          pq.offer(n);
        }
      }
    }
    int kSmallest = pq.peek();
    for(int i = 0; i < input.length; i++){
      if(input[i] == kSmallest) return i;
    }
    return -1;
  }

  public static void main(String[] args){
    oa test = new oa();
    String[] a = new String[]{"3234.html", "xys.html", "haha","7hsaa.html","7hsaa.html"};
    String[] b = new String[]{"3234.html", "sdhsfjdsh.html", "xys.html", "7hsaa.html","7hsaa.html"};
    List<String> res = test.longestCommonHistort(a, b);
//    for(String s : res){
//      System.out.println(s);
//    }

//    String[][] c = new String[3][2];
//    c[0][0] = "google.com";
//    c[0][1] = "50";
//    c[1][0] = "yahoo.com";
//    c[1][1] = "100";
//    c[2][0] = "sports.yahoo.com";
//    c[2][1] = "20";
//    Map<String, Integer> result = test.domain(c);
//    for(String str : result.keySet()){
//      Integer time = result.get(str);
//      System.out.println(str + " : " + time);
//    }

    // triangle
    int[][] test2 = new int[3][3];
    test2[0][0] = 5;
    test2[0][1] = 2;
    test2[0][2] = 8;
    test2[1][0] = 3;
    test2[1][1] = 4;
    test2[1][2] = 5;
    test2[2][0] = 5;
    test2[2][1] = 2;
    test2[2][2] = 8;
   //System.out.println(test.uniqueTriangle(test2));

    int[] test3 = new int[]{101,100,1000,3,5,2,4,6};
    //System.out.println(test.increaseDecrease(test3));
    System.out.println(test.kthSmallest(test3, 3));
  }

}



 // Prints to standard output.
    static void findStartAndEndLocations(String[][] pairs) {
        

        // Your code here.
        Map<String, List<String>> adj = new HashMap<>();
        Map<String, Integer> indegree = new HashMap<>();



        for (int i = 0; i < pairs.length; i++) {
            String left = pairs[i][0], right = pairs[i][1];
            indegree.put(right, indegree.getOrDefault(right, 0) + 1);
            if (adj.containsKey(left)) {
                adj.get(left).add(right);
            }
            else {
                adj.put(left, new ArrayList<>());
                adj.get(left).add(right);
            }
        }

        Set<String> startPoint = new HashSet<>();
        for (String s : adj.keySet()) {
            if (!indegree.containsKey(s)) {
                startPoint.add(s);
            }
        }

        Map<String, List<String>> res = new HashMap<>();
        for (String s : startPoint) {
            Set<String> visited = new HashSet<>();
            List<String> tails = new ArrayList<>();
            dfs(s, adj, visited, tails);
            Collections.sort(tails);
            res.put(s, tails);
        }


        for (String start : res.keySet()) {
            System.out.print(start + ": ");
            int len = res.get(start).size();
            for (int i = 0; i < len; i++) {
                if (i == len - 1) {
                    System.out.print(res.get(start).get(i));
                }
                else {
                    System.out.print(res.get(start).get(i) + " ");
                }
            }
            System.out.println();
        }


    }

    static void dfs(String s, Map<String, List<String>> adj, Set<String> visited, List<String> tails) {
        visited.add(s);
        if (!adj.containsKey(s)) {
            tails.add(s);
            return;
        }
        for (String string : adj.get(s)) {
            if (!visited.contains(string)) {
                dfs(string, adj, visited, tails);
            }
        }
    }

























