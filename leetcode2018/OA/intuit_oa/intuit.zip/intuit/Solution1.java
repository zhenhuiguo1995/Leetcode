/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oa;

import com.sun.org.apache.xml.internal.security.utils.XMLUtils;
import java.nio.channels.SeekableByteChannel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author liuch
 */
public class Solution1 {
    public class GraphNode{
        char startPoint;
        char endPoint;
        public GraphNode(char start,char end){
            this.startPoint = start;
            this.endPoint = end;
        }
    }
    public Map<Character,List<Character>>  input(char [][] input){
        // get the map of graph -> key is the starting point of each edge, and the value
        //is a list of all its neighbor points that it can reach
        Map<Character,List<Character>> map = getMap(input);
        // get the set of all leafNodes. if a node is not in this set, then it is a root point, and 
        // we can start our dfs from here.
        Set<Character> leafNode = getSet(input);
        //That's the output, I used a map for the output, key is the startpoint, value is the list of all
        //the end points of the start point
        Map<Character,List<Character>> result = new HashMap<>();
        for(Character c:map.keySet()){
            // if it is not a leafNode, then it is a root node and I could start my DFS here
            if(!leafNode.contains(c)){
                //use hashset here to store the result to make sure that a node will not be put into the list twice
                Set<Character> set = new HashSet<>();
                doDFS(c,set,map);
                result.put(c,new ArrayList<>(set));
            }
        }
        return result;
    }
    private void doDFS(char a, Set<Character> set, Map<Character,List<Character>> map){
        if(!map.containsKey(a)){
            set.add(a);
            return;
        }
        for(char c: map.get(a)){
            doDFS(c, set, map);
        }
    }
    private Set<Character> getSet(char [][] input){
        Set<Character> set = new HashSet<>();
        for(char[] array:input){
            set.add(array[1]);
        }
        return set;
    }
    private Map<Character,List<Character>> getMap(char [][] input){
        Map<Character,List<Character>> map = new HashMap<>();
        for(char[] array:input){
            // if the graph map doesn't has a key as this character, then it isn't a start point 
            // of any edge, then it is a end point so we add it to the result.
            if(!map.containsKey(array[0])){
                map.put(array[0], new ArrayList<>());
            }
            map.get(array[0]).add(array[1]);
        }
        return map;
    }
}
