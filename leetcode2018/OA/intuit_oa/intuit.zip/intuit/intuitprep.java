import java.util.*;

public class intuitprep {

  //domain
  public Map<String, Integer> domain (String[][] input) {
      Map<String, Integer> map = new HashMap<> ();
       for (String[] str: input) {
         int count = Integer.valueOf(str[1]);
         String domain = str[0];
         String[] parts = domain.split("\\.");
         String curr = " ";
         for (int i = parts.length -1; i >= 0 ; i--) {
           if (i == parts.length -1)
             curr = parts[i];
           else
             curr = parts[i]+"."+ curr;
           if (map.containsKey(curr))
             map.put(curr, map.get(curr) + count);
           else
             map.put(curr, count);
         }
       }
    return map;
    //List<String[]> res = new ArrayList<>();
    //for (Map.Entry<String, Integer> entry : map.entrySet()) {
    //System.out.println(entry.getKey() + "," + entry.getValue());
    // res.add(new String[]{entry.getKey(), String.valueOf(entry.getValue())});
  }

  //longest common history
  public List<String> longestCommonHistory(String[] a, String[] b){
    List<String> res = new ArrayList<>();
    int n = a.length;
    int m = b.length;
    int[][] dp = new int[n + 1][m + 1];
    int result = Integer.MIN_VALUE;
    int aEnd = 0;
    for(int i = 1; i < dp.length; i++){
      for(int j = 1; j < dp[0].length; j++){
        if(a[i - 1].equals(b[j - 1])){
          dp[i][j] = dp[i - 1][j - 1] + 1;
          if(dp[i][j] > result){
            result = dp[i][j];
            aEnd = i - 1;
          }
        }else{
          dp[i][j] = 0;
        }
      }
    }
    int i = aEnd;
    while(result > 0){
      res.add(a[i--]);
      result--;
    }
    Collections.reverse(res);

    return res;
  }

  //meeting room

  public static class Interval {
        int start;
        int end;
        Interval() { start = 0; end = 0; }
        Interval(int s, int e) { start = s; end = e; }
    }



  public boolean MeetingRooms(List<Interval> intervals, int starttime, int endtime) {
    if(intervals == null)
      return false;
    //Arrays.sort(intervals, (a,b) -> (a.start - b.start));
    intervals.sort((i1,i2) -> Integer.compare(i1.start,i2.start));

    for(int i = 0; i < intervals.size(); i++){
      /**if(intervals[i].start < intervals[i-1].end){
        return false;
      }**/
      if (starttime < intervals.get(i).end && endtime > intervals.get(i).start)//
        return false;

    }
    return true;
  }

  //merge intevals
  public List<String> merge1(List<Interval> intervals) {
    if(intervals.size() <= 1) {
      return new ArrayList<>();
    }
    intervals.sort((i1,i2) -> Integer.compare(i1.start,i2.start));

    List<Interval> res= new LinkedList<>();
    int start = intervals.get(0).start;
    int end = intervals.get(0).end;
    for(Interval i : intervals){
      if(i.start <=end){
        end = Math.max(end, i.end);
      } else {
        res.add(new Interval(start,end));
        start = i.start;
        end = i.end;

      }
    }
    res.add(new Interval(start,end));

    List<String> ans = new ArrayList<>();
    int start1 = 0;
    int end1 = res.get(res.size()-1).end;
    int begin = start1;//the beginTime of freeTime (end of last meeting)
    for (Interval i : res) {
      if (begin >= end1) {//if the start of free time is out of range(exceeds end), break the loop
        break;
      }
      if (i.start > begin) {//only add time range to res when there is a diff(free time) between two times
        ans.add(begin + "-" + Math.min(i.start, end1));//if the i.start exceeds end, we pick end to be the boundary
      }
      begin = Math.max(begin, i.end);//update begintime
    }
    return ans;
  }


  //cal1
  public int calculate(String s) {
    int len = s.length(), sign = 1, result = 0;
    Stack<Integer> stack = new Stack<>();
    for(int i=0; i < len ; i++){
      if(Character.isDigit(s.charAt(i))){
        int sum = s.charAt(i) - '0';
        while(i+1 < len && Character.isDigit(s.charAt(i+1))){
          sum = s.charAt(i+1) - '0' + sum * 10;
          i++;
        }
        result = result + sum*sign;
      } else if(s.charAt(i) == '+'){
        sign = 1;
      } else if(s.charAt(i) == '-'){
        sign = -1;
      } else if(s.charAt(i) == '('){
        stack.push(result);
        stack.push(sign);
        result = 0;
        sign = 1;
      } else if(s.charAt(i) == ')'){
        result = stack.pop()*result + stack.pop();
      }
    }
    return result;
  }

  //cal2
  public int calculate2(String s) {
    int len = s.length(), num =0;
    char sign = '+';
    Stack<Integer> stack = new Stack<>();
    for(int i =0; i < len; i++){
      if(Character.isDigit(s.charAt(i))){
        num = num*10 + (s.charAt(i) - '0');
      }
      if((!Character.isDigit(s.charAt(i))&&s.charAt(i) != ' ')
              || i == len -1){
        if(sign == '+'){
          stack.push(num);
        }
        if(sign == '-'){
          stack.push(-num);
        }
        if(sign == '*'){
          stack.push(stack.pop()*num);
        }
        if(sign == '/'){
          stack.push(stack.pop()/num);
        }
        sign = s.charAt(i);
        num = 0;
      }
    }
    int result = 0;
    for(int sum:stack ){
      result += sum;
    }
    return result;
  }

  //cal3



  //security system
  public void findUnMatch1(String[][] strs) {
    Map<String, List<Integer>> map = new HashMap<>();
    for (String[] str : strs) {
      String employee = str[0];
      String time = str[1];
      if (!map.containsKey(employee))
        map.put(employee, new ArrayList<>());
      //int t = time.length() == 3 ? Integer.valueOf(time.substring(0, 1)) * 60 + Integer.valueOf(time.substring(1)) :
      //        Integer.valueOf(time.substring(0, 2)) * 60 + Integer.valueOf(time.substring(2));
      map.get(employee).add(Integer.valueOf(time));
    }
    Map<String, List<Integer>> res = new HashMap<>();
    for (String employee : map.keySet()) {
      List<Integer> time = map.get(employee);
      Collections.sort(time);
      //map.put(employee,time);
      check(res, employee, time);
    }
    for (String employee : res.keySet()) {
      System.out.println(employee + " : ");
      List<Integer> time = res.get(employee);
      //System.out.println("sz"+res.get(employee).size());
      for (int n : time) System.out.print(n + " ");
    }
  }

  public void check(Map<String, List<Integer>> res, String employee, List<Integer> time) {
    if (time.size() <= 2) return;
    res.put(employee, new ArrayList<>());
    List<Integer> candidates = new ArrayList<>();
    int start = time.get(0);
    int end = start + 100;
    int count = 0;
    for (int i = 0; i < time.size(); i++) {
      int cur = time.get(i);
      if(time.get(time.size()-1) <= end ){
        res.put(employee,new ArrayList<>(time));
      }
      if (cur <= end) {
        candidates.add(cur);
        count++;
      } else {
        if (count >= 3) {
          res.put(employee, new ArrayList<>(candidates));
          return;
        } else {

          count = 0;
          start = time.get(i);
          end = start + 100;
          candidates = new ArrayList<>();
        }
      }
    }
  }

   public void findunmatch2(String[][] strs){
     Map<String,Integer> enter = new HashMap<>();
     Map<String,Integer> exit = new HashMap<>();

     for(String[] str:strs) {
       if (str[1] == "enter") {
         if (!enter.containsKey(str[0])) {
           enter.put(str[0], 1);
         } else {
           enter.put(str[0], enter.get(str[0]) + 1);
         }
       }
       if (str[1] == "exit") {
         if (!exit.containsKey(str[0])) {
           exit.put(str[0], 1);
         } else {
           exit.put(str[0], enter.get(str[0]) + 1);
         }
       }
     }
       List<List<String>> list = new ArrayList<>();
     List<String> lenter = new ArrayList<>();
       //List<String> lexit = new ArrayList<>();
       for(Map.Entry<String, Integer> entry: enter.entrySet()){
          if(!exit.containsKey(entry.getKey()))
            //System.out.println("enter: " + entry.getKey());
            lenter.add(entry.getKey());
          else
            if(entry.getValue()  > exit.get(entry.getKey())){
            lenter.add(entry.getKey());
          }
       }

     for(Map.Entry<String, Integer> entry: exit.entrySet()){
       if(!enter.containsKey(entry.getKey()))
         //System.out.println("exit: " + entry.getKey());
         list.get(1).add(entry.getKey());
       else
       if(entry.getValue()  > enter.get(entry.getKey())){
         //System.out.println("exit: "+ entry.getKey());
       }
     }
     list.add(lenter);
   }






  //friend list

  public List<String> output(int[][] arr) {
    Map<Integer, List<Integer>> map = new HashMap<>();
    buildUndirectedGraph(map, arr);
    List<String> res = new ArrayList<>();
    for (Map.Entry<Integer, List<Integer>> entry : map.entrySet()) {
      int cur = entry.getKey();
      List<Integer> neigh = entry.getValue();
      StringBuilder curRes = new StringBuilder();
      curRes.append(cur + " : ");
      for (int i = 0; i < neigh.size(); i++) {
        curRes.append(neigh.get(i) + " ");
      }
      res.add(curRes.toString());
    }
    return res;
  }

  public void buildUndirectedGraph(Map<Integer, List<Integer>> map, int[][] arrs) {
    for (int[] arr : arrs) {
      int a = arr[0];
      int b = arr[1];
      if (!map.containsKey(a)) map.put(a, new ArrayList<>());
      if (!map.containsKey(b)) map.put(b, new ArrayList<>());
      map.get(a).add(b);
      map.get(b).add(a);
    }
  }

  //pretask
  // pretask
  public List<String> preTask(String[][] strs) {
    List<String> res = new ArrayList<>();
    Map<String, Integer> indegree = new HashMap<>();
    buildTopo(strs, indegree);
    //放在Queue 入度

    return res;
  }

  public void buildTopo(String[][] strs, Map<String, Integer> indegree) {
    for (String[] str : strs) {
      String a = str[0];
      String b = str[1];
      indegree.put(a, 0);
      indegree.put(b, 0);
    }
    for (String[] str : strs) {
      String b = str[1];
      indegree.put(b, indegree.get(b) + 1);
    }
  }



  // q1: 只有0个parents和只有1个parent的节点.
  public List<Integer> signleParent(int[][] arrs) {
    Map<Integer, List<Integer>> map = new HashMap<>();
    buildGraph(arrs, map);
    Set<Integer> nodes = new HashSet<>();
    for (int[] arr : arrs) {
      nodes.add(arr[0]);
      nodes.add(arr[1]);
    }
    List<Integer> res = new ArrayList<>();
    for (Integer n : nodes) {
      if (!map.containsKey(n) || map.get(n).size() == 1) {
        res.add(n);
      }
    }
    return res;
  }

  public void buildGraph(int[][] arrs, Map<Integer, List<Integer>> map) {
    for (int[] arr : arrs) {
      int p = arr[0];
      int c = arr[1];
      if (!map.containsKey(p)) {
        map.put(p, new ArrayList<>());
      }
      map.get(p).add(c);
    }
  }

  // q2: 两个指定的点有没有公共祖
  public List<Integer> commonAncestor(int[][] arrs, int a, int b) {
    Map<Integer, List<Integer>> map = new HashMap<>();
    buildGraph(arrs, map);
    List<Integer> res = new ArrayList<>();
    Set<Integer> ancestor = new HashSet<>();
    search(map, a, ancestor, false, res);
    search(map, b, ancestor, true, res);
    return res;
  }

  public List<Integer> search(Map<Integer, List<Integer>> map, int target, Set<Integer> ancestor, boolean check, List<Integer> res) {
    if (!map.containsKey(target)) return null;
    List<Integer> list = map.get(target);
    for (int i = 0; i < list.size(); i++) {
      int parent = list.get(i);
      if (!check) {
        ancestor.add(parent);
        search(map, parent, ancestor, check, res);
      } else {
        if (ancestor.contains(parent)) {
          res.add(parent);
        } else {
          search(map, parent, ancestor, check, res);
        }
      }
    }
    return res;
  }

  //q3: farest ancestor
  public int farestAncestor(int[][] arrs, int target) {
    Map<Integer, List<Integer>> map = new HashMap<>();
    buildGraph(arrs, map);
    if (!map.containsKey(target)) return -1;
    Queue<Integer> queue = new LinkedList<>();
    queue.offer(target);
    int res = -1;
    while (!queue.isEmpty()) {
      int size = queue.size();
      for (int i = 0; i < size; i++) {
        int curNode = queue.poll();
        res = curNode;
        if (!map.containsKey(curNode)) continue;
        List<Integer> parents = map.get(curNode);
        for (int j = 0; j < parents.size(); j++) {
          queue.offer(parents.get(j));
        }
      }
    }
    return res;
  }




  // find rec
  public List<List<Integer>> find(int[][] arrs) {
    List<List<Integer>> res = new ArrayList<>();
    for (int i = 0; i < arrs.length; i++) {
      for (int j = 0; j < arrs[0].length; j++) {
        if (arrs[i][j] == 0) {
          List<Integer> cur = new ArrayList<>();
          cur.add(i);
          cur.add(j);
          int[] rc = searchRC(arrs, i, j);
          cur.add(rc[0]);
          cur.add(rc[1]);
          res.add(cur);
          flip(arrs, i, j, rc[0], rc[1]);
        }
      }
    }
    return res;
  }

  public int[] searchRC(int[][] arrs, int i, int j) {
    int[] res = new int[2];
    while (j < arrs[0].length && arrs[i][j] == 0) {
      j++;
    }
    while (i < arrs.length && arrs[i][j] == 0) {
      i++;
    }
    res[0] = --i;
    res[1] = --j;
    return res;
  }

  public void flip(int[][] arrs, int lcr, int lcc, int rcr, int rcc) {
     for(int i = lcr; i <=rcr  ; i++) {
       for (int j = rcc; j>= lcc; j--) {
         arrs[i][j] = 1;
       }
     }
  }
  public static void main(String[] args) {
    //test domain
    intuitprep test = new intuitprep();
    /**
    String[][] test1 = {{"google.com","60"},{"yahoo.com","50"},{"sports.yahoo.com","50"}};
    Map<String, Integer> ans = test.domain(test1);

    for(Map.Entry<String,Integer> entry : ans.entrySet()){
      System.out.println(entry.getKey()+","+entry.getValue());
    } **/

    //test lcs
    /**String[] a = {"3234.html", "xys.html", "7hsaa.html"};
    String[] b = {"3234.html", "sdhsfjdsh.html", "xys.html", "7hsaa.html"};
    List<String> ans = new ArrayList<>();
    ans = test.longestCommonHistort(a,b);
    System.out.println("0" + ans.get(0));
    System.out.println("1" + ans.get(1));
    for(String s : ans){
      System.out.println(s);
    }**/

    /**String[][] test1 = {{"Martha", "exit"},
            {"Paul", "enter"},
            {"Martha", "enter"},
            {"Martha", "exit"},
            {"Jennifer", "enter"},
            {"Paul", "enter"},
            {"Curtis", "enter"},
            {"Paul", "exit"},
            {"Martha", "enter"},
            {"Martha", "exit"},
            {"Jennifer", "exit"}};
    test.findunmatch2(test1);**/

    String[][] test1 = {{"john","830"},{"john","835"},{"john","855"},{"john","915"},{"john","930"},{"psd","1355"},{"psd","1315"},{"psd","1405"},{"psd","1630"}};
    String[][] test2 = {};
    test.findUnMatch1(test1);
    //

    /**Interval i1 = new Interval(1,3); {"john","915"},{"john","930"}
    Interval i2 = new Interval(2,6);
    Interval i3 = new Interval(8,10);
    Interval i4 = new Interval(15,18);
    List<Interval> test1 = new ArrayList<>();
    test1.add(i1);
    test1.add(i2);
    test1.add(i3);
    test1.add(i4);
    System.out.println(test1.size());

    List<String> ans = test.merge1(test1);
    System.out.println(ans.size());
    for(String s : ans){
      System.out.println(s);
    }**/

    /**Interval i1 = new Interval(1300,1500);
    Interval i2 = new Interval(930,1200);
    Interval i3 = new Interval(830,845);
    List<Interval> test1 = new ArrayList<>();
    test1.add(i1);
    test1.add(i2);
    test1.add(i3);

    System.out.println(test.MeetingRooms(test1,820,830));
    System.out.println(test.MeetingRooms(test1,1450,1500));
    System.out.println(test.MeetingRooms(test1,1100,1305));
    System.out.println(test.MeetingRooms(test1,1100,1205));
    System.out.println(test.MeetingRooms(test1,850,935));
    System.out.println(test.MeetingRooms(test1,835,1315));
    System.out.println(test.MeetingRooms(test1,835,840));
    System.out.println(test.MeetingRooms(test1,1,10));**/
  }
}
